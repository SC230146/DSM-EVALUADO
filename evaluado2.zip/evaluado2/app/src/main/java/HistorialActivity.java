import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.evaluado2.R;

public class HistorialActivity extends AppCompatActivity implements HistorialActivity3 {

    private RecyclerView recyclerView;
    private List<Compra> historialCompras;

    @Override
    protected <HistorialAdapter> void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_historial);

        recyclerView = findViewById(R.id.recyclerView_historial);
        historialCompras = getHistorialDeCompras();

        HistorialAdapter adapter = new HistorialAdapter(historialCompras);
        recyclerView.setAdapter((RecyclerView.Adapter) adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }

    private <Compra> List<Compra> getHistorialDeCompras() {
        // Obtener el historial de la base de datos o almacenamiento local
        return new ArrayList<>();
    }
}
