public class OrdenActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private TextView totalCompra;
    private Button btnConfirmar;
    private Carrito carrito;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_orden);

        recyclerView = findViewById(R.id.recyclerView_orden);
        totalCompra = findViewById(R.id.total_compra);
        btnConfirmar = findViewById(R.id.btn_confirmar);
        carrito = new Carrito(); // Recuperar el carrito de alguna manera

        OrdenAdapter adapter = new OrdenAdapter(carrito.getMedicamentos());
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        totalCompra.setText("Total: $" + carrito.calcularTotal());

        btnConfirmar.setOnClickListener(v -> {
            // Guardar el historial de compras en la base de datos
            // Luego, redirigir a la pantalla del historial
            startActivity(new Intent(OrdenActivity.this, HistorialActivity.class));
        });
    }
}
