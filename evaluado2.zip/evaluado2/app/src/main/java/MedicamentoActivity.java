public class MedicamentoActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private Button btnViewOrder;
    private List<Medicamento> medicamentoList;
    private Carrito carrito;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medicamento);

        recyclerView = findViewById(R.id.recyclerView_medicamentos);
        btnViewOrder = findViewById(R.id.btn_view_order);
        carrito = new Carrito();

        // Inicializar lista de medicamentos
        medicamentoList = getMedicamentos();

        // Configurar el adaptador del RecyclerView
        MedicamentoAdapter adapter = new MedicamentoAdapter(medicamentoList, carrito);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        btnViewOrder.setOnClickListener(v -> {
            // Navegar a la pantalla de resumen de la orden
            startActivity(new Intent(MedicamentoActivity.this, OrdenActivity.class));
        });
    }

    private List<Medicamento> getMedicamentos() {
        List<Medicamento> medicamentos = new ArrayList<>();
        // Agregar medicamentos con nombre y precio
        medicamentos.add(new Medicamento("Paracetamol", 10.00));
        medicamentos.add(new Medicamento("Ibuprofeno", 15.00));
        // Agregar 10 medicamentos en total
        return medicamentos;
    }
}
