public class LoginActivity extends AppCompatActivity {

    private EditText email, password;
    private Button btnLogin, btnRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        btnLogin = findViewById(R.id.btn_login);
        btnRegister = findViewById(R.id.btn_register);

        btnLogin.setOnClickListener(view -> loginUser());
        btnRegister.setOnClickListener(view -> registerUser());
    }

    private void loginUser() {
        String emailText = email.getText().toString();
        String passwordText = password.getText().toString();

        // Aquí agregas el código para autenticar con Firebase o con una lógica personalizada
        if (emailText.isEmpty() || passwordText.isEmpty()) {
            Toast.makeText(this, "Complete todos los campos", Toast.LENGTH_SHORT).show();
        } else {
            // Lógica de autenticación
            // startActivity(new Intent(LoginActivity.this, MenuActivity.class));
        }
    }

    private void registerUser() {
        // Lógica de registro
        // Puedes usar Firebase Authentication para registrar al usuario
    }
}
