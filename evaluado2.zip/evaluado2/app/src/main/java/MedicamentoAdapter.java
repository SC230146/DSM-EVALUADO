public class MedicamentoAdapter extends RecyclerView.Adapter<MedicamentoAdapter.ViewHolder> {

    private List<Medicamento> medicamentos;
    private Carrito carrito;

    public MedicamentoAdapter(List<Medicamento> medicamentos, Carrito carrito) {
        this.medicamentos = medicamentos;
        this.carrito = carrito;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_medicamento, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Medicamento medicamento = medicamentos.get(position);
        holder.nombre.setText(medicamento.getNombre());
        holder.precio.setText(String.valueOf(medicamento.getPrecio()));

        holder.agregarAlCarrito.setOnClickListener(v -> {
            carrito.agregarMedicamento(medicamento);
            Toast.makeText(holder.itemView.getContext(), medicamento.getNombre() + " agregado al carrito", Toast.LENGTH_SHORT).show();
        });
    }

    @Override
    public int getItemCount() {
        return medicamentos.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView nombre, precio;
        Button agregarAlCarrito;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            nombre = itemView.findViewById(R.id.nombre_medicamento);
            precio = itemView.findViewById(R.id.precio_medicamento);
            agregarAlCarrito = itemView.findViewById(R.id.btn_agregar_carrito);
        }
    }
}
